package app.service;

 

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

 
import entity.LivroEntity;

@Service
public class LivroService {

	public String save (LivroEntity livro) {
		return "Livro cadastrado com sucesso";
	}
	
	public String update (LivroEntity livro, long id) {
		return "Atualizado com sucesso";
	}
	
	public LivroEntity findById (long id) {
		
		List<LivroEntity> listaTemp = this.findAll();
		
		for (int i = 0; i < listaTemp.size(); i++) {
			if(listaTemp.get(i).getId() == id) {
				return listaTemp.get(i);
			}
		}
		
		return null;
		
	}
	
	public List<LivroEntity> findAll () {
		
		List<LivroEntity> lista = new ArrayList<>();
		lista.add(new LivroEntity(1,"Memorias Postumas de Bras Cubas", 1935, "Machado de Assis"));
		lista.add(new LivroEntity(2,"A Culpa e das estrelas", 2008, "John Green"));
		lista.add(new LivroEntity(3,"A Turma da Monica", 2010, "Mauricio de Souza"));
		
		return lista;
	}
	
	public String delete (long id) {
		
		List<LivroEntity> listaTemp = this.findAll();
		
		for (int i = 0; i < listaTemp.size(); i++) {
			if(listaTemp.get(i).getId() == id) {
				return listaTemp.get(i).getId()+" deletado com sucesso";
			}
		}
		return "Biblioteca não encontrado";
	}
	
}
