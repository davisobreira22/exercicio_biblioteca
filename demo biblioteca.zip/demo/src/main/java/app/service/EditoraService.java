package app.service;

 


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import entity.EditoraEntity;
 

@Service
public class EditoraService {

	public String save (EditoraEntity editora) {
		return "Editora cadastrado com sucesso";
	}
	
	public String update (EditoraEntity editora, long id) {
		return "Atualizado com sucesso";
	}
	
	public EditoraEntity findById (long id) {
		
		List<EditoraEntity> listaTemp = this.findAll();
		
		for (int i = 0; i < listaTemp.size(); i++) {
			if(listaTemp.get(i).getId() == id) {
				return listaTemp.get(i);
			}
		}
		
		return null;
		
	}
	
	public List<EditoraEntity> findAll () {
		
		List<EditoraEntity> lista = new ArrayList<>();
		lista.add(new EditoraEntity(1,"Seguinte", "Rua dos Coquinho"));
		lista.add(new EditoraEntity(2,"Saraiva", "Rua do Davi"));
		lista.add(new EditoraEntity(2,"Macedo", "Rua do Neymar"));
		
		return lista;
	}
	
	public String delete (long id) {
		
		List<EditoraEntity> listaTemp = this.findAll();
		
		for (int i = 0; i < listaTemp.size(); i++) {
			if(listaTemp.get(i).getId() == id) {
				return listaTemp.get(i).getId()+" deletado com sucesso";
			}
		}
		return "Biblioteca não encontrado";
	}
	
}

