package app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import entity.BibliotecaEntity;

@Service
public class BibliotecaService {

	public String save (BibliotecaEntity biblioteca) {
		return "Biblioteca cadastrado com sucesso";
	}
	
	public String update (BibliotecaEntity biblioteca, long id) {
		return "Atualizado com sucesso";
	}
	
	public BibliotecaEntity findById (long id) {
		
		List<BibliotecaEntity> listaTemp = this.findAll();
		
		for (int i = 0; i < listaTemp.size(); i++) {
			if(listaTemp.get(i).getId() == id) {
				return listaTemp.get(i);
			}
		}
		
		return null;
		
	}
	
	public List<BibliotecaEntity> findAll () {
		
		List<BibliotecaEntity> lista = new ArrayList<>();
		lista.add(new BibliotecaEntity(1,"Rua Paia", "3525-8975"));
		lista.add(new BibliotecaEntity(2, "Rua Silvino dal bóga", "3525-8971"));
		lista.add(new BibliotecaEntity(3, "Rua Thomas Turbano", "3525-3674"));
		lista.add(new BibliotecaEntity(4, "Rua Ali Tah Teocu", "3525-6174"));
		
		return lista;
	}
	
	public String delete (long id) {
		
		List<BibliotecaEntity> listaTemp = this.findAll();
		
		for (int i = 0; i < listaTemp.size(); i++) {
			if(listaTemp.get(i).getId() == id) {
				return listaTemp.get(i).getId()+" deletado com sucesso";
			}
		}
		return "Biblioteca não encontrado";
	}
	
}
